# PRD

Build a vacation tracking app for B2B HR departments.