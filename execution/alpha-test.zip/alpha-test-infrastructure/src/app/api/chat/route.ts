import { createOpenAI } from '@ai-sdk/openai';
import { streamText } from 'ai';

// The routing configuration is dynamically injected by the model.delights.pro Super-Architect
const ROUTING_CONFIG = {
    coreEngine: "anthropic/claude-3.5-sonnet",
    coreProvider: "openrouter"
};

// Initialize the optimal provider dynamically
const provider = createOpenAI({
    apiKey: process.env.API_KEY || '',
    baseURL: ROUTING_CONFIG.coreProvider === 'openrouter' ? 'https://openrouter.ai/api/v1' : undefined,
});

export const maxDuration = 30;

export async function POST(req: Request) {
    const { messages } = await req.json();

    const result = await streamText({
        model: provider(ROUTING_CONFIG.coreEngine),
        messages,
    });

    return result.toDataStreamResponse();
}
